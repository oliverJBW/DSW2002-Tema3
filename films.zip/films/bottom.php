    <footer>
        <hr>
        <small>Oliver Bermúdez Welke | Examen Tema 3</small>
    </footer>
</body>
</html>